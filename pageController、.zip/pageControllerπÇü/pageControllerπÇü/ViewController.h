//
//  ViewController.h
//  pageController、
//
//  Created by mac on 17/6/7.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIScrollViewDelegate>


@end

