//
//  ViewController.m
//  pageController、
//
//  Created by mac on 17/6/7.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController{
    NSMutableArray *arr;
    CGFloat w;
    UIScrollView *sc;
    
    CGFloat speed;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    w=[UIScreen mainScreen].bounds.size.width;
    
    speed=w;
    
    sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 79, w, 100)];
    sc.contentSize=CGSizeMake(w*6, 100);
    sc.pagingEnabled=YES;
    sc.delegate=self;
    sc.backgroundColor=[UIColor yellowColor];
    [self.view addSubview:sc];
    
    arr =[[NSMutableArray alloc]init];
    
    for (int i=0; i<6; i++) {
        UILabel *lab=[[UILabel alloc]init];
        lab.frame=CGRectMake((w-6*10-5*10)/2+i*(10 + 10), 179-10-10, 10, 10);
        if (i==0) {
            lab.backgroundColor=[UIColor whiteColor];;

        }else{
            lab.backgroundColor=[UIColor redColor];;

        }
        lab.layer.cornerRadius=5;
        lab.clipsToBounds=YES;
        [self.view addSubview:lab];
        [arr addObject:lab];
    }
    
//    UIPageControl *page=[[UIPageControl alloc]init];
//    page.backgroundColor=[UIColor redColor];
//    page.frame=CGRectMake(10, 100, 100, 30);
//    page.numberOfPages=6;
//    page.currentPage=3;
//    [page addTarget:self action:@selector(pageclick:) forControlEvents:UIControlEventValueChanged];
//    [self.view addSubview:page];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(change) userInfo:nil repeats:YES];
    
}

- (void)change{
    CGPoint point=CGPointMake(sc.contentOffset.x+speed, 0);;
    sc.contentOffset=point;
    if (point.x==5*w) {
        speed=-speed;
    }
    if (point.x==0) {
        speed=-speed;

    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
  NSInteger aint =  scrollView.contentOffset.x/w;

    for (int i=0; i<arr.count; i++) {
        UILabel *lab=[arr objectAtIndex:i];
        if (i==aint) {
            lab.backgroundColor=[UIColor whiteColor];;

        }else{
            lab.backgroundColor=[UIColor redColor];;

        }
    }
}
//
//- (void)pageclick:(UIPageControl *)page{
//    page.currentPage
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
